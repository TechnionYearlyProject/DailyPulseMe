<!-- <template>
  <div class="container">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      hello
  </div>
</template> -->
<script>
import { Line } from 'vue-chartjs'
export default {
  name: 'Chart',
  extends: Line,
  mounted () {
    // Overwriting base render method with actual data.
    this.renderChart({
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
      borderWidth: '150px',
      borderColor: 'blue',
      datasets: [
        {
          label: 'My average during months',
          backgroundColor: 'rgba(255,0,0, 0.8)',
          data: [40, 20, 12, 39, 10, 40, 39, 80, 40, 20, 12, 11]
        },
        {
          label: 'Other student average during months',
          backgroundColor: 'rgba(0,0,250, 0.8)',
          data: [85, 40, 78, 84, 65, 22, 75, 80, 65, 90, 85, 65]
        }
      ]
    })
  }
}
</script>
