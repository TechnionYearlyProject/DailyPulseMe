import os
from stat import *
 
print ("Hello World from python")