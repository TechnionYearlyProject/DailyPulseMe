package backend.entity;

public enum EventTag {
    Sport,Rest
}
