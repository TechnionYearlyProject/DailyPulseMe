package backend.Outlook;

import backend.entity.AppUser;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;

public class Outlook {

    public boolean GetTokens(AppUser user,String str){

        HttpPost rq=new HttpPost("//login.microsoftonline.com/common/oauth2/token/");
      //  rq.set
return true;

    }


}
