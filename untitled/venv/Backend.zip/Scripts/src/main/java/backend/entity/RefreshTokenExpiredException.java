package backend.entity;

public class RefreshTokenExpiredException extends Exception {
}
